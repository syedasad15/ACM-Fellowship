from flask import Flask, request, render_template, jsonify
import joblib

# Load the model and encoders
model = joblib.load('C:/Users/T L S/Desktop/ACM Project/website/degree_suggestion_model.pkl')
label_enc_interests = joblib.load('C:/Users/T L S/Desktop/ACM Project/website/label_enc_interests.pkl')
label_enc_extra_curricular = joblib.load('C:/Users/T L S/Desktop/ACM Project/website/label_enc_extra_curricular.pkl')
label_enc_degree = joblib.load('C:/Users/T L S/Desktop/ACM Project/website/label_enc_degree.pkl')

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Get data from form submission
    matric_marks = float(request.form['matric_marks'])
    inter_marks = float(request.form['inter_marks'])
    interests = request.form['interests']
    extra_curricular = request.form['extra_curricular']

    # Encode categorical features
    interests_encoded = label_enc_interests.transform([interests])[0]
    extra_curricular_encoded = label_enc_extra_curricular.transform([extra_curricular])[0]

    # Create feature array
    features = [[matric_marks, inter_marks, interests_encoded, extra_curricular_encoded]]

    # Predict degree
    predicted_degree_encoded = model.predict(features)[0]
    predicted_degree = label_enc_degree.inverse_transform([predicted_degree_encoded])[0]

    return render_template('index.html', prediction_text=f'Suggested Degree: {predicted_degree}')

if __name__ == '__main__':
    app.run(debug=True)
